<?php 
    include_once 'app/ini.php';
?>

<!DOCTYPE HTML>
<html>
<head>
    <meta charset="UTF-8">
    <title>DCC Express</title>
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
    <div class="principal" >
        <h1>DCC Express!!!</h1>
        <br>
        <div class="botones">
            <a class="boton" href="agregar-viaje.php" >Agregar Viaje</a>
            <a class="boton" href="agregar-encargo.php" >Agregar Encargo</a>
            <a class="boton" href="ver-viajes.php" >Ver Viajes</a>
            <a class="boton" href="ver-encargos.php" >Ver Encargos</a>
        </div>
        <br>
    </div>
</body>
</html>