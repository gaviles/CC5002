<?php

/**
 * Homework 2 CC5002
 * @author Gustavo Aviles <gustavo@gaviles.com>
 */

if( isset($_GET['form']) ){
    include_once 'app/ini.php';
    
    $bSuccess = true;
    
    // call to the given save controller
    echo "<pre>";
    if( $_GET['form'] == "encargo" ){
        
        echo "encargo".PHP_EOL;
        var_dump($_POST);
        
        $descripcion = filter_input(INPUT_POST, 'descripcion');
        $espacio = filter_input(INPUT_POST, 'espacio-solicitado');
        $kilos = filter_input(INPUT_POST, 'kilos-solicitados');
        $origen = filter_input(INPUT_POST, 'ciudad-origen');
        $destino = filter_input(INPUT_POST, 'ciudad-destino');
        $imagen = "1.jpg";
        $email = filter_input(INPUT_POST, 'email');
        $celular = filter_input(INPUT_POST, 'celular');
        
        var_dump($_FILES);
        
        if( isset($_FILES['foto-encargo']) ){
            
            if( strpos( $_FILES['foto-encargo']['type'], 'image' ) !== false ){
                
                // image name
                $imgName = "17236123987989.jpg";
                
                var_dump($_FILES['foto-encargo']['tmp_name']);
                
                if( $_FILES['foto-encargo']['type'] == 'image/jpg' ){
                    $image = imagecreatefromjpeg($_FILES['foto-encargo']['tmp_name']);
                }
                if( $_FILES['foto-encargo']['type'] == 'image/jpeg'){
                    $image = imagecreatefromjpeg($_FILES['foto-encargo']['tmp_name']);
                }
                if( $_FILES['foto-encargo']['type'] == 'image/gif'){
                    $image = @imagecreatefromgif($_FILES['foto-encargo']['tmp_name']);
                }
                if( $_FILES['foto-encargo']['type'] == 'image/png'){
                    $image = @imagecreatefrompng($_FILES['foto-encargo']['tmp_name']);
                }
                
                echo $imgName;
                
                list($width,$height)=getimagesize($_FILES['foto-encargo']['tmp_name']);
                
                
                var_dump(getcwd().PATH_SEPARATOR);
                $pathBase = getcwd().PATH_SEPARATOR."img".PATH_SEPARATOR;
                $pathBase = "C:\\Users\\gustavo\\Documents\\GitHub\\CC5002\\Tarea 2\\";
                
                // Save image big
                $imageBig = imagecreatetruecolor(800,600);
                imagecopyresampled($imageBig,$image,0,0,0,0,800,600,$width,$height);
                // Save image medium
                $imageMedium = imagecreatetruecolor(320,240);
                imagecopyresampled($imageBig,$image,0,0,0,0,320,240,$width,$height);
                // Save image small
                $imageSmall = imagecreatetruecolor(80,80);
                imagecopyresampled($imageBig,$image,0,0,0,0,80,80,$width,$height);
                
                var_dump($pathBase);
                
                imagejpeg($imageBig, $pathBase."big\\{$imgName}", 100);
                imagejpeg($imageMedium, $pathBase."medium\\{$imgName}", 100);
                imagejpeg($imageSmall, $pathBase."small\\{$imgName}", 100);
                
                imagedestroy($imageBig);
                imagedestroy($imageMedium);
                imagedestroy($imageSmall); 
                
                $bSuccess = $db->encargo->create(
                            $descripcion,
                            $espacio,
                            $kilos,
                            $origen,
                            $destino,
                            $imagen,
                            $email,
                            $celular );
                
            }else{
                $bSuccess = false;
            }   
        }
        var_dump($bSuccess);
        
    }else if( $_GET['form'] == "viaje" ){
        echo "viaje".PHP_EOL;
        
        $origen = filter_input(INPUT_POST, 'ciudad-origen');
        $destino = filter_input(INPUT_POST, 'ciudad-destino');
        $fecha_ida = filter_input(INPUT_POST, 'fecha-ida');
        $fecha_regreso = filter_input(INPUT_POST, 'fecha-regreso');
        $kilos = filter_input(INPUT_POST, 'kilos-disponibles');
        $espacio = filter_input(INPUT_POST, 'espacio-disponible');
        $email = filter_input(INPUT_POST, 'email');
        $celular = filter_input(INPUT_POST, 'celular');
        
        $bSuccess = $db->viaje->create(
                        $origen,
                        $destino,
                        $fecha_ida,
                        $fecha_regreso,
                        $kilos,
                        $espacio,
                        $email,
                        $celular);
        
        var_dump($_POST);
        var_dump($bSuccess);
    }
    echo "</pre>";
}else{
    include_once 'inicio.php';
}

function is_image($path)
{
    $a = getimagesize($path);
    $image_type = $a[2];
     
    if(in_array($image_type , array(IMAGETYPE_GIF , IMAGETYPE_JPEG ,IMAGETYPE_PNG , IMAGETYPE_BMP)))
    {
        return true;
    }
    return false;
}